/*2-En la primera forma se eliminan las estructuras repetitivas
En la segunda forma los datos tienen que depender de la totalidad de la clave
En la tercera forma no tienen que haber datos que dependan de otros datos no clave*/
/*3*/
/*3/1*/
select (id_pedido, descripcion, fecha_compra, fecha_entrega, codigo_producto)  from pedidos where id_cliente=1;
/*3/2*/
select (id_cliente, nombre, apellido, direccion, telefono, email, fecha_alta) from clientes where cantidad=0;
/*3/3*/
select id_pedido from pedidos where descuento...;
/*3/4*/
select (id_pedido, cantidad) from detallepedido;

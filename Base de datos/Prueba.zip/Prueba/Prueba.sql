/*1*/
select nombre, area, perimetro from barrios where nro_comuna = 3;
/*2*/
select nombre, area, perimetro from barrios where nro_comuna >4 and nro_comuna<10;
/*3*/
select perimetro, area from comunas where id=5;
/*4*/
select nro_comuna from comunas where nombre = "v%";
/*5*/
select area from comunas where nombre = "%a%";
/*6*/
select perimetro from comunas where id_caso = 15;
/*7*/
select area from barrios where id_caso = 7;
/*8*/
select id, nombre, nro_comuna from barrios where numero_de_caso >6000000 and numero_de_caso<7000000;
/*9*/
select genero, edad from casos where id = 3;
/*10*/
select nombre, id from barrios where tipo_de_contagio = "En Investigacion";
/*11*/
select nombre, id from barrios where edad <18;
/*12*/
select id, numero_de_caso, genero, edad from casos where id <4;
/*13*/
select id, numero_de_caso, genero, edad from casos where nro_comuna !=13;

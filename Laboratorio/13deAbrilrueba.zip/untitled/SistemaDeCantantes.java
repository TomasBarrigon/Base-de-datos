/*
4. Crear la clase SistemaDeCantantes que tenga como atributo una lista
   de objetos de la clase Cantante llamada "cantantes".
   - Agregar un constructor por defecto.
   - Agregar un método llamado "obtenerCantantesJovenes" que retorne un
   ```ArrayList<Cantante>``` que contenga a los cantantes que tienen una edad entre 18 y 35.
   - Agregar un método llamado "agregarCancion" que reciba tres parámetros: el nombre artístico
   del cantante, nombre de la canción y
   la duración de la canción en segundos. Este método deberá agregar una
   nueva canción a la lista de canciones del artista indicado.
   */
   public class SistemaDeCantantes{
   Arraylist<Cantante> cantantes;

   public void agregarCancion(String nombreArtistico, String nombre, int duracionEnSegundos){

   }

}

/*3. Crear la clase Cantante como subclase de la clase Persona.
	- Agregarle el atributo "nombreArtístico" como variable de
	tipo String y el atributo "canciones" como variable
	de tipo ArrayList que sirva para almacenar objetos de la
	clase Canción.
	- Agregar un método que se llame "obtenerCancionesMasLargas"
	que retorne una lista con los nombres de las canciones más largas.
	- Agregar un método que se llame "agregarCanción" que reciba un nombre
	de canción y una duración en segundos.

 */
package com.company;
import java.util.ArrayList;
import java.util.Scanner;

public class Cantante extends Persona {
    private String nombreArtistico;
    Arraylist<Cancion> canciones;

    public String getNombreArtistico() {
        return nombreArtistico;
    }

    public Arraylist<Cancion> getCanciones() {
        return canciones;
    }

    public void setNombreArtistico(String nombreArtistico) {
        this.nombreArtistico = nombreArtistico;
    }

    public void setCanciones(Arraylist<Cancion> canciones) {
        this.canciones = canciones;
    }

    public void obtenerCancionesMasLargas(){
        System.out.printIn esUnaCancionLarga;
    }



    public class agregarCancion {

        public static void main(String[] args) {
            Scanner ingresoNombre = new Scanner(System.in);
            String nombre = ingresoNombre.nextLine();

            Scanner ingresoDuracion = new Scanner(System.in);
            int duracionEnSegundos = ingresoDuracion.nextInt();
        }
    }
}

/*5. Crear 1 objeto de la clase Cantante utilizando el constructor por
   defecto y luego cambiarle el nombre artístico utilizando un "setter".
   Comprobar que el cambio se realizó correctamente utilizando un "getter".

 */
public class Main {
    public static void main(String[] args){

    Cantante c1 = new Cantante();
    c1.setNombreArtistico("Juan");
    String nombre = c1.getNombreArtistico
    }
}

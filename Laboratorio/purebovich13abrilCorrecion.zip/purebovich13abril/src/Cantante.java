/*3. Crear la clase Cantante como subclase de la clase Persona.
	- Agregarle el atributo "nombreArtístico" como variable de
	tipo String y el atributo "canciones" como variable
	de tipo ArrayList que sirva para almacenar objetos de la
	clase Canción.
	- Agregar un método que se llame "obtenerCancionesLargas"
	que retorne una lista con los nombres de las canciones más largas.
	- Agregar un método que se llame "agregarCanción" que reciba un nombre
	de canción y una duración en segundos.

 */
import sun.reflect.generics.tree.VoidDescriptor;
import sun.util.resources.da.CalendarData_da;

import java.util.ArrayList;
import java.util.Scanner;

public class Cantante extends Personas {
    private String nombreArtistico;
    private ArrayList<Cancion> canciones;

    public String getNombreArtistico() {
        return nombreArtistico;
    }

    public ArrayList<Cancion> getCanciones() {
        return canciones;
    }

    public void setNombreArtistico(String nombreArtistico) {
        this.nombreArtistico = nombreArtistico;
    }

    public void setCanciones(ArrayList<Cancion> canciones) {
        this.canciones = canciones;
    }


    public ArrayList<Cancion> ObtenerCancionesLargas(){
        ArrayList<Cancion> CancionesLargas = new ArrayList<>();
        int contador=0;
        while (contador<this.canciones.size()){
            if(canciones.get(contador).esUnaCancionLarga()==true) {
                CancionesLargas.add(canciones.get(contador));
            }
            contador++;
        }
        return CancionesLargas;
    }



    public void agregarCancion (String NombreDeCancion, int DuracionEnSegundos){
        Cancion CancionAAñadir = new Cancion(NombreDeCancion, DuracionEnSegundos);
        this.canciones.add(CancionAAñadir);

    }
}

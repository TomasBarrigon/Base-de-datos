/*
4. Crear la clase SistemaDeCantantes que tenga como atributo una lista
   de objetos de la clase Cantante llamada "cantantes".
   - Agregar un constructor por defecto.
   - Agregar un método llamado "obtenerCantantesJovenes" que retorne un
   ```ArrayList<Cantante>``` que contenga a los cantantes que tienen una edad entre 18 y 35.
   - Agregar un método llamado "agregarCancion" que reciba tres parámetros: el nombre artístico
   del cantante, nombre de la canción y
   la duración de la canción en segundos. Este método deberá agregar una
   nueva canción a la lista de canciones del artista indicado.
   */
import java.util.ArrayList;

public class SistemaDeCantantes{
   ArrayList<Cantante> cantantes;

   public SistemaDeCantantes(){
      this.cantantes = new ArrayList<>();
   }

   public ArrayList<Cantante> ObtenerCantantesJovenes(){
      ArrayList<Cantante> CantantesJovenes = new ArrayList<>();
      int contador=0;
      while (contador<this.cantantes.size()){
         if(cantantes.get(contador).getEdad() > 18 && cantantes.get(contador).getEdad() < 35) {
            CantantesJovenes.add(cantantes.get(contador));
         }
         contador++;
      }
      return CantantesJovenes;
   }

   public void agregarCancion(String nombreArtistico, String nombre, int DuracionEnSegundos){
      Cancion CancionAAñadir = new Cancion(nombre, DuracionEnSegundos);
      int contador = 0;
      while (contador<this.cantantes.size()){
         if(cantantes.get(contador).getNombreArtistico()==nombreArtistico){
            cantantes.get(contador).getCanciones().add(CancionAAñadir);
            break;
         }
         contador++;
      }
   }
}

/*2. Crear la clase Canción que tenga como atributos: "nombre" (una variable de tipo String)
y "duraciónEnSegundos" (una variable de tipo int)
   - Agregar un constructor por defecto y un constructor que reciba
   un nombre y una duración expresada en segundos.
   - Agregar un método que se llame "esUnaCancionLarga" que retorne
   true si la canción tiene una duración mayor o igual a 240 segundos.

 */
public class Cancion {
    private String nombre;
    private int duracionEnSegundos;

    public Cancion(){
        this.nombre = "Song1";
        this.duracionEnSegundos = 400;
    }

    public Cancion(String nombre, int duracionEnSegundos){
        this.nombre = nombre;
        this.duracionEnSegundos = duracionEnSegundos;
    }

    public boolean esUnaCancionLarga(){
        return this.duracionEnSegundos >= 240;
    }
}